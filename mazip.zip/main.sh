#python3 -m pip install flask requests
python3 -m pip install colorama
python3 server.py